-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 13, 2023 at 09:40 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `lubaosystem`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` int(11) NOT NULL,
  `name` varchar(191) NOT NULL,
  `u_name` varchar(255) NOT NULL,
  `email` varchar(191) NOT NULL,
  `password` varchar(191) NOT NULL,
  `code` int(20) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `is_ban` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=not_ban,1=ban',
  `role` varchar(20) NOT NULL,
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `u_name`, `email`, `password`, `code`, `phone`, `is_ban`, `role`, `created_at`) VALUES
(1, 'Staff', 'staff', 'angelosorizo30@gmail.com', '$2y$10$TqFPx7avzmtHDuQ3Uapg8uecQ.RfdetLsVNW2gGK6xMe/S/j4wpSe', 0, '09876543213', 0, 'Cashier', '2023-11-16'),
(2, 'Admin', 'admin', 'wilbertumbina12@gmail.com', '$2y$10$2yPe6eB/U7CRWbLvsoKpAuXyFU0/6V6DWDCm33Zv3d04knld9YLkK', 448974, '0923332563', 0, 'Administrator', '2023-11-16'),
(4, 'Angelo Sorizo', 'staff1', 'wilbertumbina16@gmail.com', '$2y$10$gUXgKSTYtJhj9MTFgTfipehHH9cKhfIr.ebHFcVCRAHrsoiNLiMoK', 0, '09924319262', 0, 'Cashier', '2023-12-11'),
(5, 'Wilbert Umbina', '', 'testing@gmail.com', '$2y$10$NRuurt.e1QEeaIjFrt5TquFjgVfNeT/HakHxs2ilsN8SRN3HKGVKC', 0, '09321312321', 0, 'Administrator', '2023-12-13');

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `announcement_text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `announcement_text`) VALUES
(1, 'IT Departmental Shirt Arriving on December 15, 2023 '),
(2, 'Close on Monday');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` mediumtext DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`id`, `name`, `description`, `status`) VALUES
(5, 'Department Shirt', '', 0),
(6, 'UNIFORM', '', 0),
(7, 'PE UNIFORM', '', 0),
(8, 'ID LACE', '', 0),
(9, 'BAG', '', 0),
(11, 'OTHER', 'other', 0);

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

CREATE TABLE `customers` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `name`, `email`, `phone`, `status`, `created_at`) VALUES
(1, 'Wilbert Umbina', 'BSIT', '201-0377', 0, '2023-12-04');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `tracking_no` varchar(100) NOT NULL,
  `invoice_no` varchar(100) NOT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `order_date` date NOT NULL,
  `order_status` varchar(100) DEFAULT NULL,
  `refund_reason` text NOT NULL,
  `payment_mode` varchar(100) NOT NULL COMMENT 'cash, online',
  `order_placed_by_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `customer_id`, `tracking_no`, `invoice_no`, `total_amount`, `order_date`, `order_status`, `refund_reason`, `payment_mode`, `order_placed_by_id`) VALUES
(1, 0, '69461', 'BAO-121707', 440.00, '2023-12-04', 'Paid', '', 'Cash Payment', 1),
(2, 2, '24076', 'INV-820289', 880.00, '2023-12-05', 'Paid', '', 'Cash Payment', 1),
(3, 2, '69671', 'INV-474810', 1600.00, '2023-12-05', 'Paid', '', 'Cash Payment', 1),
(4, 2, '37572', 'INV-379051', 360.00, '2023-12-05', 'Refund', 'Incorrect Size', 'Cash Payment', 1),
(5, 1, '65365', 'INV-951348', 1320.00, '2023-12-05', 'Refund', 'Obsolete Order', 'Cash Payment', 1),
(6, 1, '96865', 'INV-538164', 2200.00, '2023-12-05', 'Refund', 'With Damage', 'Cash Payment', 1),
(7, 1, '48343', 'INV-191918', 360.00, '2023-12-11', 'Paid', '', 'Cash Payment', 1);

-- --------------------------------------------------------

--
-- Table structure for table `order_items`
--

CREATE TABLE `order_items` (
  `id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `price` varchar(100) NOT NULL,
  `quantity` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `order_items`
--

INSERT INTO `order_items` (`id`, `order_id`, `product_id`, `price`, `quantity`) VALUES
(1, 0, 3, '440.00', '1'),
(2, 2, 3, '440.00', '2'),
(3, 3, 7, '320.00', '5'),
(4, 4, 9, '360.00', '1'),
(5, 5, 3, '440.00', '3'),
(6, 6, 4, '440.00', '1'),
(7, 6, 10, '380.00', '1'),
(8, 6, 5, '440.00', '1'),
(9, 6, 6, '470.00', '2'),
(10, 7, 9, '360.00', '1');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `sizes` varchar(255) NOT NULL COMMENT 'XS, Small, Medium, Large, XL, XXL, XXXL, Custom',
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 0 COMMENT '0=visible,1=hidden',
  `created_at` date NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `category_id`, `name`, `sizes`, `price`, `quantity`, `image`, `status`, `created_at`) VALUES
(3, 5, 'IT Dept. Shirt', 'Small', 440.00, 0, '../assets/uploads/products/1701706415.png', 0, '2023-12-04'),
(4, 5, 'IT Dept. Shirt', 'Medium', 440.00, 49, '../assets/uploads/products/1701706448.png', 0, '2023-12-04'),
(5, 5, 'IT Dept. Shirt', 'Large', 440.00, 49, '../assets/uploads/products/1701706532.png', 0, '2023-12-04'),
(6, 5, 'IT Dept. Shirt', 'XL', 470.00, 48, '../assets/uploads/products/1701706570.png', 0, '2023-12-04'),
(7, 6, 'BUFFALO', 'XS', 320.00, 45, '../assets/uploads/products/1701706602.png', 0, '2023-12-04'),
(8, 6, 'BUFFALO', 'Small', 320.00, 20, '../assets/uploads/products/1701706639.png', 0, '2023-12-04'),
(9, 6, 'BLOUSE', 'XS', 360.00, 28, '../assets/uploads/products/1701706705.png', 0, '2023-12-04'),
(10, 6, 'BLOUSE', 'Large', 380.00, 29, '../assets/uploads/products/1701706744.png', 0, '2023-12-04'),
(11, 5, 'CS Dept. Shirt', 'Small', 440.00, 30, '../assets/uploads/products/1701706800.png', 0, '2023-12-04'),
(12, 5, 'Educ. Dept. Shirt', 'Small', 440.00, 50, '../assets/uploads/products/1701706874.png', 0, '2023-12-04'),
(13, 5, 'Entrep. Dept. Shirt', 'Small', 440.00, 50, '../assets/uploads/products/1701706930.png', 0, '2023-12-04'),
(14, 5, 'Arts in Comm. Dept. Shirt', 'Small', 440.00, 50, '../assets/uploads/products/1701706976.png', 0, '2023-12-04'),
(15, 5, 'Accountancy Dept. Shirt', 'Large', 440.00, 30, '../assets/uploads/products/1701707067.png', 0, '2023-12-04'),
(16, 5, 'ME Dept. Shirt', 'XL', 470.00, 50, '../assets/uploads/products/1701707120.png', 0, '2023-12-04'),
(17, 5, 'Midwifery Dept. Shirt', 'XXL', 470.00, 30, '../assets/uploads/products/1701707159.png', 0, '2023-12-04'),
(18, 6, 'Polo Shirt', 'Small', 400.00, 50, '../assets/uploads/products/1701707225.png', 0, '2023-12-04');

-- --------------------------------------------------------

--
-- Table structure for table `sizes`
--

CREATE TABLE `sizes` (
  `id` int(11) NOT NULL,
  `size` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `sizes`
--

INSERT INTO `sizes` (`id`, `size`) VALUES
(1, 'XS'),
(2, 'Small'),
(3, 'XS'),
(4, 'Small'),
(5, 'Medium'),
(6, 'Large'),
(7, 'XL'),
(8, 'XXL'),
(9, 'XXXL'),
(10, 'Custom');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `order_items`
--
ALTER TABLE `order_items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sizes`
--
ALTER TABLE `sizes`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `order_items`
--
ALTER TABLE `order_items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `products`
--
ALTER TABLE `products`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `sizes`
--
ALTER TABLE `sizes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
