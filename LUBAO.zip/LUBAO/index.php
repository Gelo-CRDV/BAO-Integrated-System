<?php 
include('includes/header-login.php');


if(isset($_SESSION['loggedIn'])){
    ?>
        <script>window.location.href = 'logout.php';</script>
    <?php

}
?>  

<!doctype html>

<html class="h-100" lang="en">

<head>

    <!-- Fonts and icons -->

    <script src="assets/js/webfont.min.js"></script>

    <script>

        WebFont.load({

            google: {"families":["Lato:300,400,700,900"]},

            custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ["https://ilearnu.lu.edu.ph/css/fonts.min.css"]},

            active: function() {

                sessionStorage.fonts = true;

            }

        });

    </script>



    <!-- CSS Files -->

    <link rel="stylesheet" href="assets/css/bstrap.min.css">

	<link rel="stylesheet" href="assets/css/atlantis.min.css">



    <style>

        .divider:after,

        .divider:before {

            content: "";

            flex: 1;

            height: 1px;

            background: #eee;

        }

        .h-custom {

            height: calc(100% - 30px);

        }

        @media (max-width: 450px) {

            .h-custom {

                height: 100%;

            }

        }

    </style>

</head>

<body class="h-100" style="background-image: url('/assets/img/bg/LUBAO-background.jpg'); background-position: center; background-size: cover; background-attachment: fixed;">



    <section class="h-100">
    <div class="container-fluid h-custom">
        <div class="row d-flex justify-content-center align-items-center h-100">
            <div class="col-md-8 col-lg-5 col-xl-4 text-center">
                
            </div>
            <div class="col-md-8 col-lg-5 col-xl-4 offset-xl-1">
                <div class="card card-body shadow py-5 my-5">
                    <h3 class="text-center mb-4">Welcome to Laguna&nbsp;<br>Business&nbsp;Affairs&nbsp;Office</h3>
                    
                    <form method="POST" action="login-code.php">
                        <input type="hidden" name="_token" value="z9Kq0WbTanew1dDjYBuiIcf5IhSBZJdRxw4IBUii">                        
                        <div class="form-group mt-4 mb-2">
                            <label for="u_name">Username</label>
                            <div class="input-icon">
                                <span class="input-icon-addon"><i class="fa fa-user"></i></span>
                                <input class="form-control " type="text" name="u_name" required>
                            </div>
                                                    </div>

                        <!-- Password input -->
                        <div class="form-group mb-2">
                            <label for="password">Password</label>
                            <div class="input-icon">
                                <span class="input-icon-addon"><i class="fa fa-lock"></i></span>
                                <input class="form-control " type="password" id="password" name="password" required>
                            </div>
                                                    </div>

                        <div class="text-center text-lg-start mt-0 pt-2">
                            <button type="submit" class="btn btn-success" name="loginBtn">L O G I N</button>
                        </div>

                        <div class="row  mt-4">
                            <div class="col-md-5">
                                <div class="mt-1 mb-0 mx-2">
                                    <a class="btn btn-sm btn-outline-secondary" href="forgot-password.php">Forgot My Account</a>
                                </div>
                            </div>
                            
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</section>





	<!--   Core JS Files   -->

	<script src="assets/js/jquery.3.2.1.min.js"></script>

	<script src="assets/js/popper.min.js"></script>

	<script src="assets/js/bootstrap.min.js"></script>



    <script>
    $(document).ready(function () {
        $('#recovery-link').on('click', function(e) {
            e.preventDefault();
            $('#recovery-modal').modal('show');
        });

        $('#error-options').on('click', function(e) {
            e.preventDefault();
            $('#options-modal').modal('show');
        });

        $('#recovery-form').on('submit', function(e) {
            e.preventDefault();
            var route = $(this).attr('action');
            var formData = new FormData(this);
            $.ajax({
                type: 'POST',
                url: route,
                data: formData,
                cache: false,
                contentType: false,
                processData: false,
                success: function(data) {
                    alert(data);
                },
                error: function() {
                    alert('An error occurred.');
                },
            });
        });
    });

    $(document).on('click', '#login_btn', function() {
        $('#login_btn').prop("disabled", true);
        $("#login_form").submit();
    });
</script>
;



    <script>

        
    </script>

</body>

</html>

