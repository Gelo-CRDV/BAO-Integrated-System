<?php

require '../config/function.php';

$paraResult = checkedParamId('id');

if (is_numeric($paraResult)) {
    $announcementId = validate($paraResult);

    $announcement = getById('announcements', $announcementId);

    if ($announcement['status'] == 200) {
        $announcementDeleteRes = delete('announcements', $announcementId);

        if ($announcementDeleteRes) {
            redirect('announcement.php', 'Announcement Succesfully Deleted.');
        } else {
            redirect('announcement.php', 'Error deleting announcement.');
        }
    } else {
        redirect('announcement.php', 'Announcement not Found.');
    }
} else {
    redirect('announcement.php', 'Id not Found.');
}
