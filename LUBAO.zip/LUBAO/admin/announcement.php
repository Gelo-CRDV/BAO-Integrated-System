<?php include('includes/header.php'); ?>

<div class="container-fluid px-4">
    <div class="card mt-4 shadow-sm">
        <div class="card-header mt-3 shadow-sm">
            <h4 class="mb-0">Add Announcement
            </h4>
        </div>
        <div class="card-body">
            <?php
            
            if ($_SERVER["REQUEST_METHOD"] == "POST") {
                // Retrieve announcement text from the form
                $announcementText = $_POST["announcement_text"];
            
                // Insert the announcement into the database
                $addAnnouncement = "INSERT INTO announcements (announcement_text) VALUES ('$announcementText')";
            
                // Execute the query (this is where you would typically use your database connection)
                $queryResult = $conn->query($addAnnouncement);
            
                // Check if the query was successful
                if ($queryResult === TRUE) {
                    echo '<script>
                            $(document).ready(function(){
                                $("#notification").html("Successfully Added").fadeIn().delay(3000).fadeOut();
                            });
                          </script>';
                } else {
                    echo '<script>
                            $(document).ready(function(){
                                $("#notification").html("Cannot Add.").fadeIn().delay(3000).fadeOut();
                            });
                          </script>';
                }
            }
            
            

            // Fetch all announcements from the database
            $result = $conn->query("SELECT * FROM announcements");
            ?>

            <div class="row">
            
                <?php while ($row = $result->fetch_assoc()) : ?>
                    <div class="col-md-6 mb-3">

                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">Announcement</h5>
                                <p class="card-text"><?php echo $row["announcement_text"]; ?></p>
                                <div class="text-end">
                                    <a href="edit-announcement.php?id=<?php echo $row['id']; ?>" class="btn btn-warning btn-sm">Edit</a>
                                    <a href="delete-announcement.php?id=<?php echo $row['id']; ?>" class="btn btn-danger btn-sm">Delete</a>
                                </div>
                            </div>
                        </div>
                    </div>
                <?php endwhile; ?>
            </div>

            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="announcement_text">Create Announcement *</label>
                        <textarea name="announcement_text" class="form-control" rows="4" required></textarea>
                    </div>
                    <div class="col-md-12 mb-3 text-end">
                        <br />
                        <button type="submit" class="btn btn-primary">Save</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
