<?php

require '../config/function.php';


$paraResult = checkedParamId('id');

if(is_numeric($paraResult)){

    $adminId = validate($paraResult);

    $admin = getById('admins', $adminId);
    if($admin['status'] == 200)
    {
        $adminDeleteRes = delete('admins', $adminId);
        if($adminDeleteRes)
        {
            redirect('admins.php', 'Admin Succesfully Deleted.');
        }
        else
        {
            redirect('admins.php', 'Something Went Wrong!');
        }
    }
    else
    {
        redirect('admins.php', $admin['message']);
    }
    //echo $adminId;
}else{
    redirect('admins.php', 'Something Went Wrong!');
}


?>