<?php include('includes/header.php'); 
$totalSales = 0; // Initialize total sales variable

// Add this function to your PHP code
function formatDate($date) {
    // Check if the date is not empty before formatting
    if (!empty($date)) {
        // Convert the date to a DateTime object
        $dateTime = new DateTime($date);
        // Format the order date as yyyy-mm-dd
        return $dateTime->format('Y-m-d');
    }
    return ''; // Return empty string if the date is empty
}
?>
<div class="container-fluid px-4"> 
    <div class="card mt-4">
        <div class="card-header shadow-sm ">
            <div class="container">
                <div class="row">
                    <div class="col-md-4">
                        <h4 class="mb-3 mb-md-0">Order Summary</h4>
                    </div>
                    <div class="col-md-8">
                        <form action="" method="GET" class="d-flex flex-wrap align-items-center">
                            <div class="mb-2 col-6 col-md-3 ">
                            
                                <input type="date" 
                                    name="start_date" 
                                    class="form-control"
                                    value="<?= isset($_GET['start_date']) ? formatDate($_GET['start_date']) : ''; ?>"
                                />
                            </div>
                            <div class="mb-2 col-6 col-md-3 ">
                            
                                <input type="date" 
                                    name="end_date" 
                                    class="form-control"
                                    value="<?= isset($_GET['end_date']) ? formatDate($_GET['end_date']) : ''; ?>"
                                />
                            </div>
                            <div class="mb-2 col-6 col-md-5">
                                <button type="submit" class="btn btn-primary btn-block mb-2 mb-md-0">Filter</button>
                                <a href="orders.php" class="btn btn-danger btn-block mb-2 mb-md-0">Reset</a>
                                <button type="button" id="exportExcel" class="btn btn-success btn-block">Export to Excel</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="card-body">
            <?php 
                if (isset($_GET['start_date']) && isset($_GET['end_date'])) {
                    $startDate = validate($_GET['start_date']);
                    $endDate = validate($_GET['end_date']);

                    if ($startDate != '' && $endDate != '') {
                        $query = "SELECT o.*, c.* FROM orders o, customers c 
                            WHERE c.id = o.customer_id 
                            AND o.order_date='$startDate'
                            AND o.order_status='Paid' ORDER BY o.id DESC";
                    }
                    elseif ($startDate != '' && $endDate == '') {
                        $query = "SELECT o.*, c.* FROM orders o, customers c 
                            WHERE c.id = o.customer_id 
                            AND o.order_date='$startDate'
                            AND o.order_status='Paid' ORDER BY o.id DESC";
                    }
                    else {
                        $query = "SELECT o.*, c.* FROM orders o, customers c 
                            WHERE c.id = o.customer_id AND o.order_status='Paid' ORDER BY o.id DESC";
                    }

                } else {
                    $query = "SELECT o.*, c.* FROM orders o, customers c 
                        WHERE c.id = o.customer_id AND o.order_status='Paid' ORDER BY o.id DESC";
                }
                
                $orders = mysqli_query($conn, $query);
                if ($orders) {
                    if (mysqli_num_rows($orders) > 0) {
                        ?>
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered align-items-center justify-content-center">
                                    <thead>
                                        <tr>
                                            <th>Invoice No.</th>
                                            <th>Student Name</th>
                                            <th>Student No.</th>
                                            <th>Order Date</th>
                                            <th>Order Status</th>
                                            <th>Total Amount</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($orders as $orderItem) :
                                            $totalSales += $orderItem['total_amount']; // Add order amount to total sales
                                            ?>
                                            <tr>
                                                <td class="fw-bold"><?= $orderItem['invoice_no'] ?></td>
                                                <td><?= $orderItem['name'] ?></td>
                                                <td><?= $orderItem['student_no'] ?></td>             
                                                <td><?= date('d M, Y', strtotime($orderItem['order_date'])); ?></td>
                                                <td><?= $orderItem['order_status'] ?></td>        
                                                <td><?= $orderItem['total_amount'] ?></td>        
                                                <td>
                                                    <a href="orders-view.php?track=<?= $orderItem['tracking_no'] ?>" class="btn btn-warning mb-0 px-2 btn-sm">View</a>
                                                    <a href="orders-view-print.php?track=<?= $orderItem['tracking_no'] ?>" class="btn btn-success mb-0 px-2 btn-sm">Print</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                    <tfoot>
                                        <tr>
                                            <td colspan="5" class="text-end fw-bold">Total Sales:</td>
                                            <td class="fw-bold"><?= number_format($totalSales, 2) ?></td>
                                        </tr>
                                    </tfoot>
                                </table>
                            </div>
                        <?php
                    } else {
                        echo "<h5>No Record Available</h5>";
                    }
                } else {
                    echo "<h5>No Record Found</h5>";
                }
            ?>
        </div>
    </div>
</div>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Add a click event listener to the export button
        document.getElementById('exportExcel').addEventListener('click', function () {
            // Call a function to export the data to Excel
            exportToExcel();
        });

        // Function to export data to Excel
        function exportToExcel() {
            // You can use a library like DataTables (https://datatables.net/) for better Excel export support
            // For simplicity, let's assume a basic export function here

            // Create a form and append it to the body
            var form = document.createElement('form');
            form.method = 'POST';
            form.action = 'export-to-excel.php'; // Replace with the actual export script

            // Add hidden input fields to pass any necessary data to the export script
            var startDateInput = document.createElement('input');
            startDateInput.type = 'hidden';
            startDateInput.name = 'start_date';
            startDateInput.value = document.querySelector('input[name="start_date"]').value;
            form.appendChild(startDateInput);

            var endDateInput = document.createElement('input');
            endDateInput.type = 'hidden';
            endDateInput.name = 'end_date';
            endDateInput.value = document.querySelector('input[name="end_date"]').value;
            form.appendChild(endDateInput);

            // Append the form to the body and submit it
            document.body.appendChild(form);
            form.submit();
        }
    });
</script>
<?php include('includes/footer.php'); ?>
