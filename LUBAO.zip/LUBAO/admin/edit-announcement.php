<?php
include('includes/header.php');

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve edited announcement text from the form
    $editedText = $_POST["edited_text"];
    $announcementId = $_POST["announcement_id"];

    // Update the announcement in the database
    $sql = "UPDATE announcements SET announcement_text = '$editedText' WHERE id = $announcementId";

    if ($conn->query($sql) === TRUE) {
        echo '<div class="alert alert-success" role="alert">Announcement updated successfully</div>';
        echo '<a href="announcement.php" class="btn btn-primary">Back to Announcements</a>';
    } else {
        echo '<div class="alert alert-danger" role="alert">Error updating announcement: ' . $conn->error . '</div>';
    }
}

// Check if the 'id' parameter is set in the URL
if (isset($_GET['id'])) {
    // Retrieve announcement information from the database
    $announcementId = $_GET['id'];
    $result = $conn->query("SELECT * FROM announcements WHERE id = $announcementId");

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $existingText = $row["announcement_text"];
?>

<div class="container-fluid px-4">
    <div class="card mt-4 shadow-sm">
        <div class="card-header mt-3 shadow-sm">
            <h4 class="mb-0">Edit Announcement
                <a href="announcement.php" class="btn btn-primary float-end">Back</a>
            </h4>
        </div>
        <div class="card-body">
            <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                <input type="hidden" name="announcement_id" value="<?php echo $announcementId; ?>">
                <div class="row">
                    <div class="col-md-12 mb-3">
                        <label for="edited_text">Edited Announcement *</label>
                        <textarea name="edited_text" class="form-control" rows="4" required><?php echo $existingText; ?></textarea>
                    </div>
                    <div class="col-md-12 mb-3 text-end">
                        <br />
                        <button type="submit" class="btn btn-primary">Save Changes</button>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>

<?php
    } else {
        echo '<div class="alert alert-danger" role="alert">Announcement not found</div>';
    }
}

include('includes/footer.php');
?>
