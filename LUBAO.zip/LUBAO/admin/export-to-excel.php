<?php

// Include the Composer autoloader
require __DIR__ . './vendor/autoload.php';
include('../config/dbcon.php');

use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;



// Replace these placeholders with your actual dates
$start_date = isset($_GET['start_date']) ? mysqli_real_escape_string($conn, $_GET['start_date']) : '';

$end_date = isset($_GET['end_date']) ? mysqli_real_escape_string($conn, $_GET['end_date']) : null;

if ($end_date) {
    $query = "SELECT o.*, c.* FROM orders o, customers c 
        WHERE c.id = o.customer_id 
        AND o.order_date >= '$start_date' AND o.order_date <= '$end_date'
        AND o.order_status='Paid' ORDER BY o.id DESC";
} else {
    $query = "SELECT o.*, c.* FROM orders o, customers c 
        WHERE c.id = o.customer_id 
        AND o.order_date = '$start_date'
        AND o.order_status='Paid' ORDER BY o.id DESC";
}

$result = $conn->query($query);

try {
    // Create a new Spreadsheet
    $spreadsheet = new Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Set column headers
    $sheet->setCellValue('A1', 'Invoice No.');
    $sheet->setCellValue('B1', 'Student Name');
    $sheet->setCellValue('C1', 'Student No.');
    $sheet->setCellValue('D1', 'Order Date');
    $sheet->setCellValue('E1', 'Order Status');
    $sheet->setCellValue('F1', 'Total Amount');

    // Fetch data from the database
    $row = 1; // Start from the first row for data
    while ($orderItem = $result->fetch_assoc()) {
        $sheet->setCellValue('A2' . $row, $orderItem['invoice_no']);
        $sheet->setCellValue('B2' . $row, $orderItem['name']);
        $sheet->setCellValue('C2' . $row, $orderItem['phone']);
        $sheet->setCellValue('D2' . $row, date('d M, Y', strtotime($orderItem['order_date'])));
        $sheet->setCellValue('E2' . $row, $orderItem['order_status']);
        $sheet->setCellValue('F2' . $row, $orderItem['total_amount']);
        $row++;
    }

    // Save the spreadsheet as an Excel file
    $writer = new Xlsx($spreadsheet);
    $filename = $end_date ? 'exported_orders_' . $start_date . '_to_' . $end_date . '.xlsx' : 'exported_orders_' . $start_date . '.xlsx';

    // Set the appropriate headers for Excel file download
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="' . $filename . '"');
    header('Cache-Control: max-age=0');

    // Save the Excel file to the output stream
    $writer->save('php://output');
    exit();
} catch (\Exception $e) {
    // Handle any exceptions
    echo 'Error: ' . $e->getMessage();
}
?>
