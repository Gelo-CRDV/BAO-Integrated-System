$(document).ready(function () {

    alertify.set('notifier','position', 'top-right');

    $(document).on('click', '.increment', function () {

        var $quantityInput = $(this).closest('.qtyBox').find('.qty');
        var productId = $(this).closest('.qtyBox').find('.prodId').val();
        var currentValue = parseInt($quantityInput.val());

        if(!isNaN(currentValue)){
            var qtyVal = currentValue + 1;
            $quantityInput.val(qtyVal);
            quantityIncDec(productId, qtyVal);
        }
        location.reload();
        
    });

    $(document).on('click', '.decrement', function () {

        var $quantityInput = $(this).closest('.qtyBox').find('.qty');
        var productId = $(this).closest('.qtyBox').find('.prodId').val();
        var currentValue = parseInt($quantityInput.val());

        if(!isNaN(currentValue) && currentValue > 1){
            var qtyVal = currentValue - 1;
            $quantityInput.val(qtyVal);
            quantityIncDec(productId, qtyVal);
        }
        location.reload();
    });

    function quantityIncDec(prodId, qty){

        $.ajax({
            type: "POST",
            url: "orders-code.php",
            data: {
                'productIncDec' : true,
                'product_id' :  prodId,
                'quantity' :  qty
            },
            dataType: "dataType",
            success: function (response){
                var res = JSON.parse(response);

                if(res.status == 200){
                    $('#productArea').load(' #productContent');
                    alertify.success(res.message);
                }else{
                    $('#productArea').load(' #productContent');
                    alertify.error(res.message);
                }
            }
        })
    }

    //proceed to place order button click
    $(document).on('click', '.proceedToPlace', function () {
        //console.log('proceedToPlace');

        var cphone = $('#cphone').val();
        var payment_mode = $('#payment_mode').val();

        if(payment_mode == ''){
            swal("Business Affairs Office","Select your payment mode","warning");
            return false;
        }

        if(cphone == '' && !$.isNumeric(cphone)){
            swal("Business Affairs Office","Enter Student No.","warning");
            return false;
        }

            var data = {
                'proceedToPlaceBtn': true,
                'cphone': cphone,
                'payment_mode': payment_mode,
            };

        $.ajax({
            type: "POST",
            url: "orders-code.php",
            data: data,
            success: function(response){
                var res = JSON.parse(response);
                if(res.status == 200){
                    window.location.href = "order-summary.php";
                }else if(res.status == 404){
                    swal(res.message, res.message, res.status_type, {
                        buttons: {
                            cancel: "Cancel",
                            catch: {
                                text: "Add Student",
                                catch: "catch",
                            },
                            
                        }
                    })
                    .then((value) => {
                        switch(value){
                            case "catch":
                                $('#c_phone').val(cphone);
                                $('#addCustomerModal').modal('show');
                                //console.log('Pop the Student add modal');
                                break;
                            default: 
                        }
                    });
                }else{
                    swal(res.message, res.message, res.status_type);
                }
            }

        });

    });

    $(document).on('click', '.saveCustomer', function () {

        var c_name = $('#c_name').val();
        var c_phone = $('#c_phone').val();
        var c_email = $('#c_email').val();

        if(c_name != '' && c_phone != '')
        {
            if(c_phone)
            {

                var data = {
                    'saveCustomerBtn': true,
                    'name': c_name,
                    'phone': c_phone,
                    'email': c_email,
                };

                $.ajax({
                    type: "POST",
                    url: "orders-code.php",
                    data: data,
                    success: function(response){
                        
                        var res = JSON.parse(response);

                        if(res.status == 200){
                            swal(res.message,res.message,res.status_type);
                            $('#addCustomerModal').modal('hide');
                        }else if(res.status == 422){
                            swal(res.message,res.message,res.status_type);
                        }else{
                            swal(res.message,res.message,res.status_type);
                        }

                    }
                });

            }
            else{
                swal("Enter valid student number", "", "warning");
            }
        }
        else
        {
            swal("Please fill the required fields", "", "warning");
        }

    });

    $(document).on('click', '#saveOrder', function () {


        $.ajax({
            type: "POST",
            url: "orders-code.php",
            data: {
                'saveOrder' : true
            },
            success: function(response){
                var res = JSON.parse(response);
                
                if(res.status == 200){
                    swal(res.message, res.message, res.status_type);
                    $('#orderPlaceSuccessMessage').text(res.message);
                    $('#orderSuccessModal').modal('show');

                }else{
                    swal(res.message, res.message, res.status_type);
                }
            
            
            }
        
        });

    });

});

function processRefund() {
    // Get refund reason from the textbox
    var refundReason = document.getElementById("refundReason").value;

    // Make an AJAX request to the server
    var xhr = new XMLHttpRequest();
    xhr.open("POST", "refund_process.php", true);
    xhr.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

    // Send refund reason to the server
    xhr.send("refundReason=" + refundReason);

    // Handle the response from the server
    xhr.onreadystatechange = function () {
        if (xhr.readyState == 4 && xhr.status == 200) {
            // Display a success message or handle any other response from the server
            alert(xhr.responseText);
        }
    };
}

function printMyBillingArea(){
    var divContents = document.getElementById("myBillingArea").innerHTML;
    var a = window.open('','');
    a.document.write('<html><title>Business Affairs Office</title>');
    a.document.write('<body style="font-family: fangsong;">');
    a.document.write(divContents);
    a.document.write('</body></html>');
    a.document.close();
    a.print();
}


window.jsPDF = window.jspdf.jsPDF;
var docPDF = new jsPDF({
    unit: 'mm',
    format: [58, 150]  // Set the width and height
});

function downloadPDF(invoiceNo){

    var elementHTML = document.querySelector("#myBillingArea");
    docPDF.html( elementHTML, {
        callback: function(){
            docPDF.save(invoiceNo+'.pdf');
        },
        x: 5,
        y: 5,
        width: 150,
        windowWidth: 550
    });
}