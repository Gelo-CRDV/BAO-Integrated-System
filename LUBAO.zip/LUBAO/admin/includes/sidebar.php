<?php
    $page = substr($_SERVER['SCRIPT_NAME'], strrpos($_SERVER['SCRIPT_NAME'], "/") +1);

?>

<div id="layoutSidenav_nav" class="bs-teal">
                <nav class="sb-sidenav accordion sb-sidenav-light shadow" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            
                            <a class="nav-link <?= $page == 'index.php' ? 'active':''; ?>" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>

                            <a class="nav-link <?= $page == 'announcement.php' ? 'active':''; ?>" href="announcement.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-bullhorn"></i></div>
                                Announcement
                            </a>

                            <a class="nav-link <?= $page == 'stocks.php' ? 'active':''; ?>" href="stocks.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-cube"></i></div>
                                Manage Stocks
                            </a>

                            <!-- <a class="nav-link " href="order-create.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-bell"></i></div>
                                Create Order
                            </a> -->

                            

                            <a class="nav-link <?= ($page == 'refund.php.php') || ($page == 'refund.php.php' ) ? 'collapse active':'collapsed'; ?>" 
                            href="#" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#collapseRefund" aria-expanded="false" aria-controls="collapseRefund">
                                <div class="sb-nav-link-icon"><i class="fas fa-money-bill "></i></div>
                                Process Refund
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>

                            <div class="collapse 
                            <?= ($page == 'refund.php') || ($page == 'refund-info.php') ? 'show':''; ?>" 
                            id="collapseRefund" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link <?= $page == 'refund.php' ? 'active':''; ?>" href="refund.php">Process Refund</a>
                                    <a class="nav-link <?= $page == 'refund-view.php' ? 'active':''; ?>" href="refund-view.php">View Refund</a>
                                </nav>
                            </div>
                            
                            <a class="nav-link <?= ($page == 'categories-create.php') || ($page == 'categories.php' ) ? 'collapse active':'collapsed'; ?>" 
                            href="#" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#collapseCategory" aria-expanded="false" aria-controls="collapseCategory">
                                <div class="sb-nav-link-icon"><i class="fas fa-sort "></i></div>
                                Categories
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>

                            <div class="collapse 
                            <?= ($page == 'categories-create.php') || ($page == 'categories.php') ? 'show':''; ?>" 
                            id="collapseCategory" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link <?= $page == 'categories-create.php' ? 'active':''; ?>" href="categories-create.php">Create Category</a>
                                    <a class="nav-link <?= $page == 'categories.php' ? 'active':''; ?>" href="categories.php">View Categories</a>
                                </nav>
                            </div>

                            
                            <a class="nav-link <?= ($page == 'products-create.php') || ($page == 'products.php' ) ? 'collapse active':'collapsed'; ?>" 
                            href="#" 
                            data-bs-toggle="collapse" 
                            data-bs-target="#collapseProduct" aria-expanded="false" aria-controls="collapseProduct">
                                <div class="sb-nav-link-icon"><i class="fas fa-shirt"></i></div>
                                Products
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>

                            <div class="collapse
                            <?= ($page == 'products-create.php') || ($page == 'products.php') ? 'show':''; ?>" 
                            id="collapseProduct" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link <?= $page == 'products-create.php' ? 'active':''; ?>" href="products-create.php">Create Product</a>
                                    <a class="nav-link <?= $page == 'products.php' ? 'active':''; ?>" href="products.php">View Products</a>
                                </nav>
                            </div>
                            

                            <!-- <div class="sb-sidenav-menu-heading">Manage Users</div>

                            <a class="nav-link <?= ($page == 'customers-create.php') || ($page == 'customers.php' ) ? 'collapse active':'collapsed'; ?>" 
                            href="#" 
                                data-bs-toggle="collapse" 
                                data-bs-target="#collapseCustomers" 
                                aria-expanded="false" 
                                aria-controls="collapseCustomers">
                                <div class="sb-nav-link-icon"><i class="fas fa-person fa-xl"></i></div>
                                Customers
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse 
                            " 
                            id="collapseCustomers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link " href="customers-create.php">Add Customer</a>
                                    <a class="nav-link " href="customers.php">View Customers</a>
                                </nav>
                            </div> -->

                            <a class="nav-link <?= ($page == 'admins-create.php') || ($page == 'admins.php' ) ? 'collapse active':'collapsed'; ?>" 
                            href="#" 
                                data-bs-toggle="collapse" 
                                data-bs-target="#collapseAdmins" 
                                aria-expanded="false" 
                                aria-controls="collapseAdmins">
                                <div class="sb-nav-link-icon"><i class="fas fa-user"></i></div>
                                Admins/Staff
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse
                            <?= ($page == 'admins-create.php') || ($page == 'admins.php') ? 'show':''; ?>" 
                            id="collapseAdmins" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link <?= $page == 'admins-create.php' ? 'active':''; ?>" href="admins-create.php">Add Staff/Admin</a>
                                    <a class="nav-link <?= $page == 'admins.php' ? 'active':''; ?>" href="admins.php">View Staff/Admin</a>
                                </nav>
                            </div>
                            <div class="sb-sidenav-menu-heading">REPORTS</div>
                            <a class="nav-link <?= $page == 'orders.php' ? 'active':''; ?>" href="orders.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Order Summary
                            </a>
                        </div>
                    </div>
                    
                </nav>
            </div>