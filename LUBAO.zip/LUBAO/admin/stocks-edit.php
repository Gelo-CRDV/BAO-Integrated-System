<?php include('includes/header.php'); ?>

<div class="container-fluid px-4">

    <div class="card mt-4 shadow-sm">
        <div class="card-header mt-4 ">
            <h4 class="mb-0">Update Stocks
                <a href="stocks.php" class="btn btn-primary float-end">Back</a>
            </h4>
        </div>
        <div class="card-body">
            <?php alertMessage(); ?>

            <form action="code.php" method="POST" enctype="multipart/form-data">

                <?php
                $paramValue = checkedParamId('id');
                if (!is_numeric($paramValue)) {
                    echo '<h5>Id is not an integer</h5>';
                    return false;
                }

                $product = getById('products', $paramValue);
                if ($product) {
                    if ($product['status'] == 200) {
                ?>

                        <input type="hidden" name="product_id" value="<?= $product['data']['id'] ?>" />

                        <div class="row">

                            <div class="col-md-12 mb-3">
                                <label for="">Product Name *</label>
                                <input type="text" name="name" required value="<?= $product['data']['name']; ?>" class="form-control" />
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="">Current Quantity</label>
                                <input type="text" name="current_quantity" value="<?= $product['data']['quantity']; ?>" class="form-control" readonly />
                            </div>

                            <div class="col-md-4 mb-3">
                                <label for="">Quantity to Add *</label>
                                <input type="text" name="quantity_to_add" required class="form-control" />
                            </div>

                            <div class="col-md-6 mb-3 ">
                                <br />
                                <button type="submit" name="updateStocks" class="btn btn-danger">Update</button>
                            </div>
                        </div>
                <?php
                    } else {
                        echo '<h5>' . $product['message'] . 'g</h5>';
                    }
                } else {
                    echo '<h5>Something Went Wrong</h5>';
                    return false;
                }
                ?>
            </form>
        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>
