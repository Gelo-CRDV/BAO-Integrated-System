<?php  

include('../config/function.php');

if(isset($_POST['saveAdmin']))
{
    $name = validate($_POST['name']);
    $u_name = validate($_POST['u_name']);
    $email = validate($_POST['email']);
    $password = validate($_POST['password']);
    $phone = validate($_POST['phone']);
    $is_ban = isset($_POST['is_ban']) == true ? 1:0;
    $role = validate($_POST['role']);

    if($name != '' && $email != '' && $password != ''){

        $emailCheck = mysqli_query($conn, "SELECT * FROM admins WHERE email='$email'");
        if ($emailCheck){
            if(mysqli_num_rows($emailCheck) > 0){
                redirect('admin-create.php', 'Email already used by another user.');
            }
        }

        $bcrypt_password = password_hash($password, PASSWORD_BCRYPT);

        $data = [
            'name' => $name,
            'u_name' => $u_name,
            'email'=> $email,
            'password'=> $bcrypt_password,
            'phone' => $phone,
            'is_ban' => $is_ban,
            'role' => $role

        ];
        $result = insert('admins', $data);

        if($result){
            redirect('admins.php', 'Admin Created Succesfully!');

        }else{
            redirect('admins-create.php', 'Something Went Wrong!');

        }
        
    }else{
        redirect('admin-create.php', 'Please fill required fields.');
    }

}

if(isset($_POST['updateAdmin']))
{
    $adminId = validate($_POST['adminId']);

    $adminData = getById('admins', $adminId);
    if($adminData['status'] != 200)
    {
        redirect('admins-edit.php?id='.$adminId, 'Please fill required fields.');
    }

    $name = validate($_POST['name']);
    $u_name = validate($_POST['u_name']);
    $email = validate($_POST['email']);
    $password = validate($_POST['password']);
    $phone = validate($_POST['phone']);
    $is_ban = isset($_POST['is_ban']) == true ? 1:0;
    $role = validate($_POST['role']);

    $EmailCheckQuery = "SELECT * FROM admins WHERE email='$email' AND id!='$adminId'";
    $chechResult = mysqli_query($conn, $EmailCheckQuery);
    if($chechResult){
        if(mysqli_num_rows($chechResult) > 0 ){
            redirect('admins-edit.php?='.$adminId,'Your email is already used by other user');
        }
    }

    if($password != ''){
        $hashedPassword = password_hash($password, PASSWORD_BCRYPT);
    }else{
        $hashedPassword = $adminData['data']['password'];
    }

    if($name != '' && $email != '')
    {
        $data = [
            'name' => $name,
            'u_name' => $u_name,
            'email'=> $email,
            'password'=> $hashedPassword,
            'phone' => $phone,
            'is_ban' => $is_ban,
            'role' => $role
        ];

        $result = update('admins', $adminId, $data);

        if($result){
            redirect('admins-edit.php?id='.$adminId, 'Admin Updated Succesfully!');

        }else{
            redirect('admins-edit.php?id='.$adminId, 'Something Went Wrong!');

        }
    }
    else
    {
        redirect('admins-create.php', 'Please fill required fields.');
    }
}

if(isset($_POST['saveCategory']))
{
    $name = validate($_POST['name']);
    $description = validate($_POST['description']);
    $status = isset($_POST['status']) == true ? 1:0;

    $data = [
        'name' => $name,
        'description'=> $description,
        'status' => $status

    ];
    $result = insert('categories', $data);

    if($result){
        redirect('categories.php', 'Catgeory Created Succesfully!');

    }else{
        redirect('categories-create.php', 'Something Went Wrong!');

    }
}

if(isset($_POST['updateCategory']))
{
    $categoryId = validate($_POST['categoryId']);
    $name = validate($_POST['name']);
    $description = validate($_POST['description']);
    $status = isset($_POST['status']) == true ? 1:0;

    $data = [
        'name' => $name,
        'description'=> $description,
        'status' => $status

    ];
    $result = update('categories', $categoryId, $data);

    if($result){
        redirect('categories-edit.php?id='.$categoryId, 'Catgeory Updated Succesfully!');

    }else{
        redirect('categories-edit.php?id='.$categoryId, 'Something Went Wrong!');

    }
}


if(isset($_POST['saveProduct']))
{
    $category_id = validate($_POST['category_id']);
    $name = validate($_POST['name']);
    $sizes = validate($_POST['sizes']);
    $price = validate($_POST['price']);
    $quantity = validate($_POST['quantity']);
    $status = isset($_POST['status']) == true ? 1:0;

    if($_FILES['image'] > 0)
    {
        $path = "../assets/uploads/products";
        $image_ext = pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);

        $filename = time().'.'.$image_ext;

        move_uploaded_file($_FILES['image']['tmp_name'], $path."/".$filename);
        $finalImage = "../assets/uploads/products/".$filename;
    }
    else
    {
        $finalImage = '';
    }

    $data = [
        'category_id' => $category_id,
        'name' => $name,
        // 'description'=> $description,
         'sizes'=> $sizes,
        'price'=> $price,
        'quantity'=> $quantity,
       
        'image'=> $finalImage,
        'status' => $status

    ];
    $result = insert('products', $data);

    if($result){
        redirect('products.php', 'Product Created Succesfully!');

    }else{
        redirect('products-create.php', 'Something Went Wrong!');

    }
}


if(isset($_POST['updateProduct']))
{
    $product_id = validate($_POST['product_id']);

    $productData = getById('products',$product_id);
    if(!$productData){
        redirect('products.php', 'No such products found');
    }

    $category_id = validate($_POST['category_id']);
    $name = validate($_POST['name']);
    $description = validate($_POST['description']);
    $price = validate($_POST['price']);
    $sizes = validate($_POST['sizes']);
    $status = isset($_POST['status']) == true ? 1:0;

    if($_FILES['image'] > 0)
    {
        $path = "../assets/uploads/products";
        $image_ext = pathinfo($_FILES['image']['name'],PATHINFO_EXTENSION);

        $filename = time().'.'.$image_ext;

        move_uploaded_file($_FILES['image']['tmp_name'], $path."/".$filename);
        $finalImage = "../assets/uploads/products/".$filename;

        $deleteImage = "../".$productData['data']['image'];
        if(file_exists($deleteImage)){
            unlink($deleteImage);
        }
    }
    else
    {
        $finalImage = $productData['data']['image'];
    }

    $data = [
        'category_id' => $category_id,
        'name' => $name,
        // 'description'=> $description,
         'sizes'=> $sizes,
        'price'=> $price,
        'quantity'=> $quantity,
       
        'image'=> $finalImage,
        'status' => $status

    ];
    $result = update('products',$product_id, $data);

    if($result){
        redirect('products-edit.php?id='.$product_id, 'Product Updated Succesfully!');

    }else{
        redirect('products-edit.php?id='.$product_id, 'Something Went Wrong!');

    }
}

if(isset($_POST['updateStocks'])) {
    $product_id = validate($_POST['product_id']);
    $name = validate($_POST['name']);
    $current_quantity = validate($_POST['current_quantity']);
    $quantity_to_add = validate($_POST['quantity_to_add']);

    // Calculate the new quantity by adding the quantity_to_add to the current_quantity
    $new_quantity = $current_quantity + $quantity_to_add;

    $data = [
        'name' => $name,
        'quantity' => $new_quantity
    ];

    $result = update('products', $product_id, $data);

    if ($result) {
        redirect('stocks-edit.php?id=' . $product_id, 'Stocks Updated Successfully!');
    } else {
        redirect('stockss-edit.php?id=' . $product_id, 'Something Went Wrong!');
    }
}


if(isset($_POST['checkStocksBtn']))
{
    $product_id = validate($_POST['product_id']);

    $quantity = validate($_POST['quantity']);
    

    $data = [    
        'quantity'=> $quantity
    ];
    $result = update('products',$product_id, $data);

    if($result){
        redirect('stocks.php?id='.$product_id, 'Stocks Updated Succesfully!');

    }else{
        redirect('stocks.php?id='.$product_id, 'Something Went Wrong!');

    }
}

if(isset($_POST['saveCustomer']))
{
    $name = validate($_POST['name']);
    $program_course = validate($_POST['program_course']);
    $student_no = validate($_POST['student_no']);
    $status = isset($_POST['status']) ? 1:0;

    if($name != '')
    {
        $studentCheck = mysqli_query($conn, "SELECT * FROM customers WHERE student_no='$student_no'");
        if($studentCheck){
            if(mysqli_num_rows($studentCheck) > 0){
                redirect('customers.php', 'Student Number already used by another user');
            }
        }

        $data = [
            'name' => $name,
            'program_course' => $program_course,
            'student_no'=> $student_no,
            'status'=> $status
    
        ];
        $result = insert('customers',$data);

        if($result){
            redirect('customers.php', 'Customer Created Succesfully!');

        }else{
            redirect('customers.php', 'Something Went Wrong!');

        }


    }
    else
    {
        redirect('customers.php', 'Please fill required fields');
    }
}


if(isset($_POST['updateCustomer']))
{
    $customerId = validate($_POST['customerId']);

    $name = validate($_POST['name']);
    $program_course = validate($_POST['program_course']);
    $student_no = validate($_POST['student_no']);
    $status = isset($_POST['status']) ? 1:0;

    if($name != '')
    {
        $studentCheck = mysqli_query($conn, "SELECT * FROM customers WHERE student_no='$student_no' AND id!='$customerId'");
        if($studentCheck){
            if(mysqli_num_rows($studentCheck) > 0){
                redirect('customers-edit.php?id='.$customerId , 'Student Number already used by another user');
            }
        }

        $data = [
            'name' => $name,
            'program_course' => $program_course,
            'student_no'=> $student_no,
            'status'=> $status
    
        ];
        $result = update('customers',$customerId, $data);

        if($result){
            redirect('customers-edit.php?id='.$customerId, 'Customer Updated Succesfully!');

        }else{
            redirect('customers-edit.php?id='.$customerId, 'Something Went Wrong!');

        }
    }
    else
    {
        redirect('customers-edit.php?id='.$customerId, 'Please fill required fields');
    }

}



?>