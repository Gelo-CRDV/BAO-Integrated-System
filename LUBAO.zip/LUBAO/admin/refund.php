<?php include('includes/header.php'); ?>


<?php alertMessage(); ?>

<div class="container-fluid px-4"> 
    <div class="card mt-4 shadow-sm">
        <div class="card-header">   
            <div class="row">
                <div class="col-md-4">
                <h4 class="mb-0">Manage Refund</h4>
                </div>
                <div class="col-md-8">
                    <form action="" method="GET">
                        <div class="row g-1">
                            <div class="col-md-4 ">
                                <input type="text" 
                                name="invoice_no" 
                                class="form-control"
                                value="<?= isset($_GET['invoice_no']) == true ? $_GET['invoice_no']:''; ?>"
                                />
                            </div>
                            <div class="col-md-4 ">
                                <button type="submit" class="btn btn-primary">Filter</button>
                                <a href="refund.php" class="btn btn-danger">Reset</a>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
        <div class="card-body">

            <?php 

            if(isset($_GET['invoice_no'])){
                $trackNo = validate($_GET['invoice_no']);
               
                if($trackNo != '' )
                {
                    $query = "SELECT o.*, c.* FROM orders o, customers c 
                    WHERE c.id = o.customer_id AND o.invoice_no='$trackNo' AND o.order_status='Paid' ORDER BY o.id DESC";
                }else{
                    $query = "SELECT o.*, c.* FROM orders o, customers c 
                    WHERE c.id = o.customer_id AND o.order_status='Paid' ORDER BY o.id DESC";
                }

            }else{
                $query = "SELECT o.*, c.* FROM orders o, customers c 
                WHERE c.id = o.customer_id AND o.order_status='Paid' ORDER BY o.id DESC";
            }
                
                $orders = mysqli_query($conn, $query);
                if($orders){
                    
                    if(mysqli_num_rows($orders) > 0){

                        ?>
                            <table class="table table-striped table-bordered align-items-center justify-content-center">
                                <thead>
                                    <tr>      
                                        <th>Invoice No.</th>
                                        <th>Student Name</th>
                                        <th>Student No.</th>
                                        <th>Order Date</th>
                                        <th>Order Status</th>
                                        <th>Payment Mode</th>
                                        <th>Action</th>
                                       
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach($orders as $orderItem) : ?>
                                        <tr>
                                           
                                            <td class="fw-bold"><?= $orderItem['invoice_no'] ?></td>
                                            <td><?= $orderItem['name'] ?></td>
                                            <td><?= $orderItem['phone'] ?></td>             
                                            <td><?= date('d M, Y', strtotime($orderItem['order_date'])); ?></td>
                                            <td><?= $orderItem['order_status'] ?></td>
                                            <td><?= $orderItem['payment_mode'] ?></td>
                                            <td>
                                                <a href="refund-info.php?track=<?= $orderItem['tracking_no'] ?>" class="btn btn-warning mb-0 px-2 btn-sm w-100">Process Refund</a>
                                                
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        <?php

                    }
                    else
                    {
                        echo "<h5>No Record Available</h5>";
                    }
                }
                else
                {
                    echo "<h5>No Record Found</h5>";
                }
            ?>

        </div>
    </div>
</div>

<?php include('includes/footer.php'); ?>