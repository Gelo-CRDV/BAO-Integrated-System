<?php

require 'config/function.php';

if(isset($_POST['loginBtn']))
{
    $email = validate($_POST['u_name']);
    $password  = validate($_POST['password']);

    if($email != '' && $password != '')
    {
        $query = "SELECT * FROM admins WHERE u_name='$email' LIMIT 1";
        $result = mysqli_query($conn, $query);
        if($result){

            if(mysqli_num_rows($result) == 1){

                $row = mysqli_fetch_assoc($result);
                $hashedPassword  = $row['password'];

                if(!password_verify($password,$hashedPassword)){
                    redirect('index.php', 'Invalid Password');
                }

                if($row['is_ban'] == 1){
                    redirect('login.php', 'Your account has been banned. Contact your Admin.');
                }

                // Assuming 'role' is the column in the 'admins' table
                    $userRole = $row['role'];

                    $_SESSION['loggedIn'] = true;
                    $_SESSION['loggedInUser'] = [
                        'id' => $row['id'],
                        'name' => $row['name'],
                        'u_name' => $row['u_name'],
                        'email' => $row['email'],
                        'phone' => $row['phone'],
                        'role' => $userRole, // Add the user's role to the session
                    ];

                    // Redirect based on the user's role
                    if ($userRole == 'Administrator') {
                        redirect('admin/index.php', 'Logged In Successfully');
                    } elseif ($userRole == 'Cashier') {
                        redirect('cashier/index.php', 'Logged In Successfully');
                    } else {
                        // Handle other roles as needed
                        redirect('index.php', 'Invalid Role');
                    }
            }else{
                redirect('index.php', 'Invalid Username');
            }
        }
        else{
            redirect('index.php', 'Something Went Wrong!');
        }
    }
    else
    {
        redirect('index.php','All fields are required to fill!');
    }
}

?>