<?php

require('fpdf.php');
require('dbcon.php');


$tracking_no = isset($_GET['tracking_no']) ? $_GET['tracking_no'] : null;

// Assuming $conn is your mysqli connection
$select = $conn->prepare("SELECT * FROM orders WHERE tracking_no = ?");
$select->bind_param('s', $tracking_no);
$select->execute();
$result = $select->get_result();
$row = $result->fetch_assoc();

$pdf = new FPDF('P', 'mm', array(58, 150));
$pdf->AddPage();

$pdf->SetFont('Arial', 'B', 8);
$pdf->Cell(40, 6, 'Laguna University', 0, 1, 'C');
$pdf->Cell(40, 1, 'Business Affairs Office', 0, 1, 'C');

$pdf->SetFont('Arial', 'B', 5);
$pdf->Cell(40, 4, '3rd Floor, Room 310 Oreta Building', 0, 1, 'C');
$pdf->Cell(40, 1, 'E-mail: ', 0, 1, 'C');
$pdf->Cell(40, 3, 'Facebook: www.fb.com/LUBusinessAffairsOffice', 0, 1, 'C');

$pdf->Line(4, 25, 55, 25);
$pdf->Ln(1);

$pdf->SetFont('Arial', 'BI', 5);
$pdf->Cell(13, 4, 'Student Name: ', 0, 0, '');

$pdf->SetFont('Courier', 'BI', 5);
$pdf->Cell(20, 4, 'Wilbert Umbin', 0, 1, ''); // Replace 'Wilbert Umbina' with the actual column name

$pdf->SetFont('Arial', 'BI', 5);
$pdf->Cell(11, 4, 'Invoice No: ', 0, 0, '');

$pdf->SetFont('Courier', 'BI', 5);
$pdf->Cell(20, 4, 'INV-31231', 0, 1, ''); // Replace 'INV-731108' with the actual column name

$pdf->SetFont('Arial', 'BI', 5);
$pdf->Cell(6, 4, 'Date: ', 0, 0, '');

$pdf->SetFont('Courier', 'BI', 5);
$pdf->Cell(20, 4, '2023-12-03', 0, 1, ''); // Replace '2023-1-12' with the actual column name




///////dito naman table

$pdf->SetFont('Arial','B',5);
$pdf->SetFillColor(208,208,208);
$pdf->Cell(5,3,'PRODUCT',1,0,'C',true);
$pdf->Cell(4,3,'QTY',1,0,'C',true);
$pdf->Cell(3,3,'PRICE',1,0,'C',true);
$pdf->Cell(2,3,'TOTAL',1,1,'C',true);

//////dito yung total eme
$pdf->SetX(4);

$pdf->SetFont('Courier','B',5);
$pdf->Cell(15,4,'',0,0,'L');
$pdf->Cell(15,4,'SUBTOTAL',1,0,'C');
$pdf->Cell(15,4,'6969',1,1,'C');

$pdf->SetX(4);

$pdf->SetFont('Courier','B',5);
$pdf->Cell(15,4,'',0,0,'L');
$pdf->Cell(15,4,'GRAND TOTAL',1,0,'C');
$pdf->Cell(15,4,'6969',1,1,'C');

$pdf->SetX(4);

$pdf->SetFont('Courier','B',5);
$pdf->Cell(15,4,'',0,0,'L');
$pdf->Cell(15,4,'Payment Mode:',1,0,'C');
$pdf->Cell(15,4,'Cash Payment',1,1,'C');


///////notice dito

$pdf->Cell(15,5,'',0,1,'');
$pdf->SetX(4);

$pdf->SetFont('Courier','B',5);
$pdf->Cell(15,4,'Important Notice: ',0,1,'');

$pdf->SetX(4);

$pdf->SetFont('Courier','',4);
$pdf->Cell(13,3,'No item will be return or refunded if you dont have 
',0,2,'');

$pdf->SetX(4);

$pdf->Cell(13,2,'the receipt with you. You can return/refund within 3 days of  
',0,1,'');

$pdf->SetX(4);

$pdf->Cell(13,2,'purchase. can return/refund within 3 days of purchase. 
',0,1,'');



$pdf->Output();
    
?>
