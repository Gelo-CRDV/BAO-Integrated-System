<?php include('includes/header.php'); ?>

<div class="container-fluid px-4">
    <div class="row">
        <div class="col-md-12">      
            <?php alertMessage(); ?>
            <h1 class="mt-4">Dashboard</h1>           
        </div>

        <div class="col-md-3 mb-3">
            <div class="card card-body bg-jusep p-3">
                <p class="text-sm mb-0 text-capitalize">Total Refund</p>
                <h5 class="fw-bold mb-0">
                    <?php 
                    $todayOrders = mysqli_query($conn, "SELECT order_status FROM orders WHERE order_status='Refund' ");
                    if ($todayOrders) {
                        if(mysqli_num_rows($todayOrders) > 0) {
                            $totalCountOrders = mysqli_num_rows($todayOrders);
                            echo $totalCountOrders;
                        }else{
                            echo "0";
                        }
                    }else{
                        echo 'Something Went Wrong';
                    }
                    ?>
                </h5>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card card-body bg-gelo p-3">
                <p class="text-sm mb-0 text-capitalize">Total Products</p>
                <h5 class="fw-bold mb-0">
                    <?= getCount('products'); ?>
                </h5>
            </div>
        </div>

        <div class="col-md-3 mb-3">
            <div class="card card-body bg-colene p-3">
                <p class="text-sm mb-0 text-capitalize">Today's Orders</p>
                <h5 class="fw-bold mb-0">
                <?php
                        $todayDate = date('Y-m-d');
                        $todayOrders = mysqli_query($conn, "SELECT * FROM orders WHERE order_date='$todayDate'");
                        if ($todayOrders) {
                            if(mysqli_num_rows($todayOrders) > 0) {
                                $totalCountOrders = mysqli_num_rows($todayOrders);
                                echo $totalCountOrders;
                            }else{
                                echo "0";
                            }
                        }else{
                            echo 'Something Went Wrong';
                        }
                    ?>
                </h5>
            </div>
        </div>

            <div class="col-md-3 mb-3">
                <div class="card card-body bg-bibot p-3">
            <p class="text-sm mb-0 text-capitalize">Total Sales</p>
            <h5 class="fw-bold mb-0 float-end">
                <?php 
                    $todayDate = date('Y-m-d');
                    $sql = "SELECT order_date, SUM(total_amount) as total_sales FROM orders WHERE order_date='$todayDate' AND order_status='Paid'";
                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        $row = $result->fetch_assoc(); // I-extract lang ang resulta kasi expected lang na isa lang ang row
                        echo "₱ " . number_format($row["total_sales"], 2); // Format ang numerical value sa 2 decimal places
                    } else {
                        echo "₱ 0.00";
                    }
                ?>
            </h5>
        </div>
    </div>
    
    </div>
    <hr/>
    <?php
$sql = "SELECT announcement_text FROM announcements ORDER BY id DESC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    // Display all announcements on each user's dashboard
    while($row = $result->fetch_assoc()) {
        $announcements[] = $row["announcement_text"];
    }
} else {
    $announcements[] = "No announcements at the moment.";
}

?>

<hr/>

<div class="table-responsive col-mb-3 ">  
    <div class="card card-body table-responsive ">
        <a class="nav-link text-center">
            <div class="sb-nav-link-icon text-center"><i class="fas fa-bullhorn"></i><strong> ANNOUNCEMENTS</strong></div>
        </a>
        <ul>
            <?php 
                foreach ($announcements as $announcement) {
                    echo '<li>' . $announcement . '</li>';
                }
            ?>
        </ul>
    </div>
</div>
        <br>
            
    <div class="table-responsive col-mb-3">
    <div class="card card-body table-responsive">

        <a class="nav-link text-center">
            <div class="sb-nav-link-icon text-center"><i class="fas fa-bell"></i><strong> STOCK SUMMARY</strong></div>
        </a>
                    <br>
        <?php
        // Query to get all products and quantities
        $sql = "SELECT name, quantity, sizes FROM products";
        $result = $conn->query($sql);

        // Check if there are results
        if ($result->num_rows > 0) {
            // Output data in a table
            echo '<table class="table table-bordered">';
            echo '<thead><tr><th>Name</th><th>Sizes</th><th>Quantity</th></tr></thead>';
            echo '<tbody>';
            while ($row = $result->fetch_assoc()) {
                echo "<tr>";
                echo "<td>{$row['name']}</td>";
                echo "<td>{$row['sizes']}</td>";
                echo "<td>{$row['quantity']}</td>";
                echo "</tr>";
            }
            echo '</tbody>';
            echo '</table>';
        } else {
            echo "No products found.";
        }
        ?>
    </div>
</div>
</div>



<?php include('includes/footer.php'); ?>
