<?php
    $page = substr($_SERVER['SCRIPT_NAME'], strrpos($_SERVER['SCRIPT_NAME'], "/") +1);

?>

<div id="layoutSidenav_nav" class="bs-teal">
                <nav class="sb-sidenav accordion sb-sidenav-light shadow" id="sidenavAccordion">
                    <div class="sb-sidenav-menu">
                        <div class="nav">
                            
                            <a class="nav-link <?= $page == 'index.php' ? 'active':''; ?>" href="index.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-tachometer-alt"></i></div>
                                Dashboard
                            </a>

                            
                            <a class="nav-link <?= $page == 'order-create.php' ? 'active':''; ?>" href="order-create.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-bell"></i></div>
                                Create Order
                            </a>

                            <a class="nav-link <?= $page == 'orders.php' ? 'active':''; ?>" href="orders.php">
                                <div class="sb-nav-link-icon"><i class="fas fa-list"></i></div>
                                Orders
                            </a>
                            
                            <div class="sb-sidenav-menu-heading">Manage Users</div>

                            <a class="nav-link <?= ($page == 'customers-create.php') || ($page == 'customers.php' ) ? 'collapse active':'collapsed'; ?>" 
                            href="#" 
                                data-bs-toggle="collapse" 
                                data-bs-target="#collapseCustomers" 
                                aria-expanded="false" 
                                aria-controls="collapseCustomers">
                                <div class="sb-nav-link-icon"><i class="fas fa-person fa-xl"></i></div>
                                Customers
                                <div class="sb-sidenav-collapse-arrow"><i class="fas fa-angle-down"></i></div>
                            </a>
                            <div class="collapse 
                            <?= ($page == 'customers-create.php') || ($page == 'customers.php') ? 'show':''; ?>" 
                            id="collapseCustomers" aria-labelledby="headingOne" data-bs-parent="#sidenavAccordion">
                                <nav class="sb-sidenav-menu-nested nav">
                                    <a class="nav-link <?= $page == 'customers-create.php' ? 'active':''; ?>" href="customers-create.php">Add Customer</a>
                                    <a class="nav-link <?= $page == 'customers.php' ? 'active':''; ?>" href="customers.php">View Customers</a>
                                </nav>
                            </div>
    
                        </div>
                    </div>
                    
                </nav>
            </div>