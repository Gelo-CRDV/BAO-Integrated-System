<?php

require '../config/function.php';


$paraResultID = checkedParamId('id');

if(is_numeric($paraResultID)){

    $customerId = validate($paraResultID);

    $customer = getById('customers', $customerId);
    
    if($customer['status'] == 200)
    {
        $response = delete('customers', $customerId);
        if($response)
        {
            redirect('customers.php', 'Category Succesfully Deleted.');
        }
        else
        {
            redirect('customers.php', 'Something Went Wrong!');
        }
    }
    else
    {
        redirect('customers.php', $customer['message']);
    }
}else{
    redirect('customers.php', 'Something Went Wrong!');
}

?>