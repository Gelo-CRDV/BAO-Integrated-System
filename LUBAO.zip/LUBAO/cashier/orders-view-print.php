
<?php 

include('includes/header.php'); ?>

<div class="container-fluid px-4"> 
    <div class="card mt-4 shadow-sm">
        <div class="card-header">
            <h4 class="mb-0">Print Order
            <a href="orders.php" class="btn btn-danger btn-sm float-end">Back</a>
            </h4>
            
        </div>
        <div class="card-body">
                <div id="myBillingArea">
                <?php
                    if(isset($_GET['track']))
                    {
                        $trackingNo = validate($_GET['track']);
                        if($trackingNo == '')
                        {   
                            ?>
                                <div class="text-center py-5">
                                    <h5>Please provide tracking number</h5>
                                    <div>
                                        <a href="orders.php" class="btn btn-primary mt-4 w-25">Go back to Orders</a>
                                    </div>
                                </div>
                            <?php
                        }

                        $orderQuery = "SELECT o.*, c.* FROM orders o, customers c 
                                WHERE c.id=o.customer_id AND tracking_no='$trackingNo' LIMIT 1";
                        $orderQueryRes = mysqli_query($conn, $orderQuery);
                        
                        if(!$orderQueryRes){
                            echo "<h5>Something Went Wrong</h5>";
                            return false;
                        }

                        if(mysqli_num_rows($orderQueryRes) > 0)
                        {
                            $orderDataRow = mysqli_fetch_assoc($orderQueryRes);
                            ?>
                            <table style="width: 58mm; margin-bottom: 20px;">
                            <tbody>
                                <tr>
                                    <td style="text-align: center;" colspan="1">
                                        <h4 style="font-size: 13px; line-height: 16px; margin: 2px; padding:0;">Laguna University<br>Business Affairs Office</h4>
                                        
                                    </td>
                                    
                                </tr>
                                <tr>
                                <td style="text-align: center;">
                                        <p style="font-size: 10px; line-height: 12px; margin: 2px; padding:0;">3rd Floor, Room 310 Oreta Building</p>
                                        <p style="font-size: 10px; line-height: 12px; margin: 2px; padding:0;">Laguna Sports Complex, Bubukal, Sta. Cruz Laguna</p>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <h5 style="font-size: 14px; line-height: 16px; margin: 0px; padding:0;">Student Details</h5>
                                        <p style="font-size: 13px; line-height: 13px; margin: 0px; padding:0;">Name: <?=  $orderDataRow['name'] ?> </p>
                                        <p style="font-size: 13px; line-height: 14px; margin: 0px; padding:0;">Student No.: <?=  $orderDataRow['phone'] ?> </p>

                                        <h5 style="font-size: 14px; line-height: 16px; margin: 0px; padding:0;">Receipt Details</h5>
                                        <p style="font-size: 13px; line-height: 13px; margin: 0px; padding:0;">Invoice No: <strong><?=  $orderDataRow['invoice_no']; ?></strong> </p>
                                        <p style="font-size: 13px; line-height: 14px; margin: 0px; padding:0;">Invoice Date: <?=  date('d M Y'); ?> </p>
                                        <p style="font-size: 13px; line-height: 14px; margin: 0px; padding:0;">Staff Name: <?= $_SESSION['loggedInUser']['name']; ?></p>
                                        
                                    </td>
                                </tr>
                            </tbody>
                        </table>

                            <?php
                        }
                        else
                        {
                            echo "<h5>No such data found! try again</h5>";
                            return false;
                        }

                        $orderItemQuery = "SELECT oi.quantity as orderItemQuantity, oi.price as orderItemPrice, o.*, oi.*, p.* 
                    FROM orders o, order_items oi, products p 
                    WHERE oi.order_id=o.id AND p.id=oi.product_id AND o.tracking_no='$trackingNo' ";

$orderItemQueryRes = mysqli_query($conn, $orderItemQuery);

if ($orderItemQueryRes) {
    if (mysqli_num_rows($orderItemQueryRes) > 0) {
        ?>
        <div class="table-responsive mb-3">
            <table style="width: 58mm;" cellpadding="5">
                <tbody>
                    <?php
                    $orderItems = array();
                    $totalAmount = 0;

                    foreach ($orderItemQueryRes as $key => $row) :
                        $productId = $row['product_id'];

                        // Initialize the product in the orderItems array if not exists
                        if (!isset($orderItems[$productId])) {
                            $orderItems[$productId] = array(
                                'name' => $row['name'],
                                'quantity' => 0,
                                'price' => 0,
                            );
                        }

                        // Update the quantity and price for the product
                        $orderItems[$productId]['quantity'] += $row['orderItemQuantity'];
                        $orderItems[$productId]['price'] += $row['orderItemPrice'] * $row['orderItemQuantity'];

                        // Update the total amount
                        $totalAmount += $row['orderItemPrice'] * $row['orderItemQuantity'];
                    endforeach;

                    // Display order details
                    foreach ($orderItems as $productId => $item) :
                    ?>
                    
                        <tr>
                        
                            <td><?= $item['name']; ?> x <?= $item['quantity']; ?> <?= number_format($item['price'] / $item['quantity'], 2); ?></td>
                        </tr>
                    <?php endforeach; ?>

                    <tr>
                        <td>Total Price: <strong><?= number_format($totalAmount, 2); ?></strong></td>
                    </tr>

                    <tr>
                        <td colspan="5">
                            <h3 style="font-size: 13px; line-height: 17px; margin: 2px; padding:0;">
                                No item will be returned or refunded if you don't have the receipt with you.
                                You can return/refund within 3 days of purchase.
                            </h3>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
<?php
   

                                }
                                else
                                {
                                    echo "<h5>No such data found! try again</h5>";
                                    return false;   
                                }
                            }
                            else
                            {
                                echo "<h5>Something Went Wrong</h5>";
                                return false;
                            }
                    }
                    else
                    {
                        ?>
                                <div class="text-center py-5">
                                    <h5>No Tracking Number Parameter Found</h5>
                                    <div>
                                        <a href="orders.php" class="btn btn-primary mt-4 w-25">Go back to Orders</a>
                                    </div>
                                </div>
                        <?php
                    }
                ?>
                </div>
            <div class="mt-4 text-end">
                <button class="btn btn-success px-4 mx-1" onclick="printMyBillingArea()">Print</button>
                <button class="btn btn-danger px-4 mx-1" onclick="downloadPDF('<?=  $orderDataRow['invoice_no']; ?>')">Download PDF</button>
            </div>
        </div>
    </div>
</div

<?php include('includes/footer.php'); ?>