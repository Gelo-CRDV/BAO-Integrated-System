<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Business Affairs Office</title>
    <link href="assets/css/bootstrap.min.css" rel="stylesheet"/>
    <link href="../admin/assets/css/style.css" rel="stylesheet"/>
    <link rel="icon" type="image/png" sizes="32x32" href="../assets/img/icons/logoicon.png">
    <link rel="icon" type="image/png" sizes="16x16" href="../assets/img/icons/logoicon.png">
  </head>
  <body>

<?php include('navbar.php'); ?>
