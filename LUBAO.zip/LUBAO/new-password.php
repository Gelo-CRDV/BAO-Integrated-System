<?php require_once "controllerUserData.php"; 
include('includes/header-reset.php');
?>
<?php 
$email = $_SESSION['email'];
if($email == false){
  header('Location: login-user.php');
}
?>



<div class="py-5 bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow rounded-4">
                    <div class="p-5">
                        <h4 class="text-dark mb-3 text-center fw-bold">Setup New Password</h4>
                        <form action="new-password.php" method="POST" autocomplete="off">
                        <?php 
                    if(isset($_SESSION['info'])){
                        ?>
                        <div class="alert alert-success text-center" style="padding: 0.4rem 0.4rem">
                            <?php echo $_SESSION['info']; ?>
                        </div>
                        <?php
                    }
                    ?>
                    <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                            <div class="mb-3">
                                <input type="password" name="password" class="form-control" placeholder="Create New Password" required />
                            </div>
                            <div class="mb-3">
                                <input type="password" name="cpassword" class="form-control" placeholder="Confirm New Password" required />
                            </div>
                            <div class="mt-3">
                                <button type="submit" name="change-password" value="" class="btn btn-primary w-100 mt-2">
                                    Change
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>