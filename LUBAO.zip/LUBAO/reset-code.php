<?php 

require_once "controllerUserData.php";
include('includes/header-reset.php');
?>
<?php


error_reporting(E_ALL);
ini_set('display_errors', 1);
?>


<div class="py-5 bg-light">
    <div class="container mt-5">
        <div class="row justify-content-center">
            <div class="col-md-6">
                <div class="card shadow rounded-4">
                    <div class="p-5">
                        <h4 class="text-dark mb-3 text-center fw-bold">Code Verification</h4>
                        <form action="reset-code.php" method="POST" autocomplete="off">
                        <?php 
                    if(isset($_SESSION['info'])){
                        ?>
                        <div class="alert alert-success text-center" style="padding: 0.4rem 0.4rem">
                            <?php echo $_SESSION['info']; ?>
                        </div>
                        <?php
                    }
                    ?>
                    <?php
                    if(count($errors) > 0){
                        ?>
                        <div class="alert alert-danger text-center">
                            <?php
                            foreach($errors as $showerror){
                                echo $showerror;
                            }
                            ?>
                        </div>
                        <?php
                    }
                    ?>
                            <div class="mb-3">
                                
                                <input type="text" name="otp" class="form-control" placeholder="Enter OTP" required />
                            </div>
                            <div class="mt-3">
                                <button type="submit" name="check-reset-otp" value="" class="btn btn-primary w-100 mt-2">
                                    Submit
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

    
